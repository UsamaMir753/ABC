$(document).ready(function(){
    $('#icon').click(function(){
        $('ul').toggleClass('show');
    });
});




var sliderimg =document.getElementById("sliderimg");

var images = new Array(
    "images/indexbgnew1.jpg",
    "images/bg new 1.jpg",
    "images/new bg img.jpeg",
    "images/indexbgnew2.jpg"
    );
   
    var len = images.length;
    var i = 0;

   function slider(){
       if(i > len-1){
           i = 0;
       }
       sliderimg.src = images[i];
       i++;
       setTimeout('slider()',3000);
   }



